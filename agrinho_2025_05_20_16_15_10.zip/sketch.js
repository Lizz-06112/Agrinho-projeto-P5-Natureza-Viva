function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let sunY = 100;
let plantHeight = 50;
let raining = false;
let drops = [];

function setup() {
  createCanvas(600, 400);
  button = createButton('Fazer Chover');
  button.position(20, 20);
  button.mousePressed(startRain);
}

function draw() {
  background(135, 206, 235); // Céu azul

  drawSun();
  drawClouds();
  drawGround();
  drawPlant();

  if (raining) {
    makeItRain();
  }
}

function drawSun() {
  fill(255, 204, 0);
  noStroke();
  ellipse(500, sunY, 80, 80); // Sol fixo
}

function drawClouds() {
  fill(255);
  ellipse(150, 100, 100, 60);
  ellipse(180, 100, 100, 60);
  ellipse(130, 80, 80, 50);
}

function drawGround() {
  fill(34, 139, 34); // Verde escuro
  rect(0, height - 50, width, 50);
}

function drawPlant() {
  fill(34, 139, 34);
  rect(width / 2 - 5, height - 50 - plantHeight, 10, plantHeight); // Caule
  fill(0, 200, 0);
  ellipse(width / 2 - 10, height - 50 - plantHeight + 10, 15, 10); // Folhas
  ellipse(width / 2 + 10, height - 50 - plantHeight + 10, 15, 10);
}

function startRain() {
  raining = true;
  plantHeight += 10; // Planta cresce quando chove
}

function makeItRain() {
  for (let i = 0; i < 5; i++) {
    drops.push({ x: random(width), y: 0 });
  }

  fill(0, 100, 255);
  for (let i = 0; i < drops.length; i++) {
    ellipse(drops[i].x, drops[i].y, 5, 10);
    drops[i].y += 5;
  }

  // Limita número de gotas
  if (drops.length > 500) {
    drops.splice(0, 100);
  }
}
